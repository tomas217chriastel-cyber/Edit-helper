/* Edit Helper panel logic. Runs in the CEP panel's Chromium context with
 * Node.js integration enabled (--enable-nodejs --mixed-context in the
 * manifest), so `require()` works directly here alongside the DOM. */

const { execFile } = require("child_process");
const fs = require("fs");
const path = require("path");
const https = require("https");
const os = require("os");

const csInterface = new CSInterface();

// getSystemPath() can return "" on some setups; os.tmpdir() is always an
// absolute, writable path, so it's a safe fallback instead of "." (which
// resolves relative to Premiere's own process directory and isn't writable).
function getCacheDir() {
    let base = "";
    try { base = csInterface.getSystemPath(CSInterface.SystemPath.USER_DATA); } catch (e) {}
    if (!base) base = os.tmpdir();
    return path.join(base, "edit-helper-cache");
}

// ---------------------------------------------------------------------------
// Settings (persisted in localStorage - this is per-panel, local to the
// machine; API keys never leave the machine except in the direct HTTPS call
// to Giphy/Tenor's own servers to run the search the user asked for)
// ---------------------------------------------------------------------------
const DEFAULT_SETTINGS = {
    giphyKey: "",
    tenorKey: "",
    localFolder: "",
    presetsFolder: "",
    ffmpegPath: "ffmpeg",
    whisperPath: "whisper",
    targetLufs: -16,
    minGapSeconds: 0.2
};

// Recently downloaded memes/GIFs, stored separately from settings since it
// grows over time - a simple capped list, newest first.
function loadRecentDownloads() {
    try { return JSON.parse(localStorage.getItem("eh_recent_downloads") || "[]"); }
    catch (e) { return []; }
}

function addRecentDownload(entry) {
    const list = loadRecentDownloads();
    list.unshift(entry);
    localStorage.setItem("eh_recent_downloads", JSON.stringify(list.slice(0, 40)));
}

function loadSettings() {
    try {
        const raw = localStorage.getItem("eh_settings");
        if (!raw) return Object.assign({}, DEFAULT_SETTINGS);
        return Object.assign({}, DEFAULT_SETTINGS, JSON.parse(raw));
    } catch (e) {
        return Object.assign({}, DEFAULT_SETTINGS);
    }
}

function saveSettings(settings) {
    localStorage.setItem("eh_settings", JSON.stringify(settings));
}

let settings = loadSettings();

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------
function $(id) { return document.getElementById(id); }

function setStatus(msg, isError) {
    const el = $("statusBar");
    el.textContent = msg;
    el.className = isError ? "status error" : "status";
}

function evalScript(script) {
    // CEP's own evalScript reports any uncaught exception (including calling
    // a function that doesn't exist, e.g. after an incomplete update) as the
    // generic string "EvalScript error." with no further detail. Wrapping
    // every call in our own try/catch turns that into a real, readable
    // error message we can actually act on.
    const wrapped = `(function(){ try { return (${script}); } catch (e) { return JSON.stringify({ ok: false, error: String(e) }); } })()`;
    return new Promise((resolve) => {
        csInterface.evalScript(wrapped, (result) => {
            try { resolve(JSON.parse(result)); }
            catch (e) { resolve({ ok: false, error: "Bad response from Premiere: " + result }); }
        });
    });
}

// ---------------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------------
document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
        document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
        document.querySelectorAll(".panel-view").forEach((v) => v.classList.remove("active"));
        tab.classList.add("active");
        $(tab.dataset.target).classList.add("active");
    });
});

// ---------------------------------------------------------------------------
// Timeline: remove gaps
// ---------------------------------------------------------------------------
$("btnRemoveGaps").addEventListener("click", async () => {
    setStatus("Scanning timeline for empty gaps...");
    const scope = $("gapScope").value;
    const minGap = parseFloat($("minGap").value) || 0;
    settings.minGapSeconds = minGap;
    saveSettings(settings);

    const script = `$$eh_removeGaps(${minGap}, "${scope}")`;
    const result = await evalScript(script);
    if (!result.ok) { setStatus("Error: " + result.error, true); return; }
    setStatus(`Removed ${result.removed} gap(s)${result.skipped ? ", " + result.skipped + " could not be removed" : ""}.`);
});

// ---------------------------------------------------------------------------
// Audio: one-click loudness normalization
// ---------------------------------------------------------------------------
function runFfmpegLoudnorm(filePath, targetI) {
    return new Promise((resolve) => {
        const args = ["-i", filePath, "-af", `loudnorm=I=${targetI}:TP=-1.5:LRA=11:print_format=json`, "-f", "null", "-"];
        execFile(settings.ffmpegPath, args, { maxBuffer: 1024 * 1024 * 20 }, (err, stdout, stderr) => {
            const text = stderr || "";
            const match = text.match(/\{[\s\S]*\}/);
            if (!match) {
                resolve({ ok: false, error: "ffmpeg did not return loudness data. Is ffmpeg installed and on PATH?" });
                return;
            }
            try {
                const data = JSON.parse(match[0]);
                resolve({ ok: true, inputI: parseFloat(data.input_i), inputTp: parseFloat(data.input_tp) });
            } catch (e) {
                resolve({ ok: false, error: "Could not parse ffmpeg output: " + e.message });
            }
        });
    });
}

function computeGainDb(inputI, inputTp, targetI) {
    if (isNaN(inputI) || isNaN(inputTp)) return 0;
    let gain = targetI - inputI;
    const maxAllowedGain = -1.0 - inputTp; // keep true peak under -1 dBTP to avoid clipping
    if (gain > maxAllowedGain) gain = maxAllowedGain;
    return Math.round(gain * 10) / 10;
}

$("btnNormalize").addEventListener("click", async () => {
    const onlySelected = $("normalizeScope").value === "selected";
    const targetI = parseFloat($("targetLufs").value) || -16;
    settings.targetLufs = targetI;
    saveSettings(settings);

    setStatus("Reading clips from the timeline...");
    const info = await evalScript(`$$eh_getClipSources(${onlySelected})`);
    if (!info.ok) { setStatus("Error: " + info.error, true); return; }

    const clips = info.clips;
    if (!clips.length) {
        setStatus(onlySelected ? "No audio clips selected." : "No audio clips found on the timeline.", true);
        return;
    }

    setStatus(`Measuring loudness of ${clips.length} clip(s) with ffmpeg...`);
    const cache = new Map();
    const entries = [];
    let failures = 0;

    for (let i = 0; i < clips.length; i++) {
        const clip = clips[i];
        setStatus(`Measuring loudness (${i + 1}/${clips.length}): ${clip.name}`);

        let measurement = cache.get(clip.mediaPath);
        if (!measurement) {
            measurement = await runFfmpegLoudnorm(clip.mediaPath, targetI);
            cache.set(clip.mediaPath, measurement);
        }

        if (!measurement.ok) { failures++; continue; }

        const gainDb = computeGainDb(measurement.inputI, measurement.inputTp, targetI);
        entries.push({ trackIndex: clip.trackIndex, clipIndex: clip.clipIndex, gainDb: gainDb });
    }

    if (!entries.length) {
        setStatus("Could not measure any clips. " + (failures ? "Make sure ffmpeg is installed (see Settings)." : ""), true);
        return;
    }

    setStatus("Applying gain to clips in Premiere...");
    const applyResult = await evalScript(`$$eh_applyAudioGains(${JSON.stringify(JSON.stringify(entries))})`);
    if (!applyResult.ok) { setStatus("Error applying gain: " + applyResult.error, true); return; }

    setStatus(`Normalized ${applyResult.applied} clip(s) to ${targetI} LUFS.` + (failures ? ` (${failures} clip(s) could not be measured.)` : ""));
});

// ---------------------------------------------------------------------------
// Subtitles: Whisper transcription + styled, pop-animated caption overlay
// ---------------------------------------------------------------------------
// 5 trendy caption looks, defined as ASS (Advanced SubStation Alpha) style
// lines. ASS is the format every "animated TikTok-style caption" tool burns
// under the hood (via ffmpeg's libass renderer) - it's the only reliable way
// to get per-line scale/pop animation without needing to hand-build video
// frames. Colours are ASS's native &HAABBGGRR hex order.
const SUBTITLE_STYLES = {
    boldPop: {
        label: "Bold Pop", fontName: "Poppins ExtraBold", fontSize: 84,
        primaryColour: "&H00FFFFFF", outlineColour: "&H00000000", backColour: "&H00000000",
        bold: -1, borderStyle: 1, outline: 5, shadow: 0, alignment: 2, marginV: 90
    },
    yellowImpact: {
        label: "Yellow Impact", fontName: "Poppins ExtraBold", fontSize: 84,
        primaryColour: "&H0000FFFF", outlineColour: "&H00000000", backColour: "&H00000000",
        bold: -1, borderStyle: 1, outline: 5, shadow: 0, alignment: 2, marginV: 90
    },
    neonGlow: {
        label: "Neon Glow", fontName: "Poppins SemiBold", fontSize: 78,
        primaryColour: "&H00FFFFFF", outlineColour: "&H00FF00FF", backColour: "&H00000000",
        bold: -1, borderStyle: 1, outline: 4, shadow: 2, alignment: 2, marginV: 90
    },
    cleanMinimal: {
        label: "Clean Minimal", fontName: "Poppins Medium", fontSize: 58,
        primaryColour: "&H00FFFFFF", outlineColour: "&H00202020", backColour: "&H00000000",
        bold: 0, borderStyle: 1, outline: 2, shadow: 1, alignment: 2, marginV: 70
    },
    karaokeBox: {
        label: "Karaoke Box", fontName: "Poppins SemiBold", fontSize: 68,
        primaryColour: "&H00FFFFFF", outlineColour: "&H00000000", backColour: "&H80000000",
        bold: -1, borderStyle: 3, outline: 8, shadow: 0, alignment: 2, marginV: 90
    }
};

function renderStylePreview(styleKey) {
    const style = SUBTITLE_STYLES[styleKey];
    const preview = $("stylePreview");
    const stroke = style.borderStyle === 3 ? "none" : `-2px 0 ${style.outlineColour === "&H00000000" ? "#000" : "#c0c"}`;
    preview.innerHTML = `<span style="color:#fff;font-family:'Poppins','Segoe UI',sans-serif;background:${style.borderStyle === 3 ? "rgba(0,0,0,0.6)" : "transparent"};-webkit-text-stroke:2px ${style.outlineColour === "&H00000000" ? "#000" : "#e040e0"};">${style.label}</span>`;
    preview.querySelector("span").style.color = style.primaryColour === "&H0000FFFF" ? "#ffe500" : "#fff";
}
$("subtitleStyle").addEventListener("change", () => renderStylePreview($("subtitleStyle").value));
renderStylePreview($("subtitleStyle").value);

$("strokeEnabled").addEventListener("change", () => {
    $("strokeWidth").disabled = !$("strokeEnabled").checked;
});
$("strokeWidth").addEventListener("input", () => {
    $("strokeWidthValue").textContent = `Stroke width: ${$("strokeWidth").value}`;
});
$("glowAmount").addEventListener("input", () => {
    const v = parseInt($("glowAmount").value, 10);
    $("glowAmountValue").textContent = v === 0 ? "Glow: off" : `Glow: ${v}`;
});

function parseSrt(text) {
    const blocks = text.replace(/\r/g, "").split(/\n\n+/);
    const cues = [];
    blocks.forEach((block) => {
        const lines = block.split("\n").filter(Boolean);
        const timeLineIndex = lines.findIndex((l) => l.indexOf("-->") !== -1);
        if (timeLineIndex === -1) return;
        const match = lines[timeLineIndex].match(/(\d\d):(\d\d):(\d\d),(\d\d\d)\s*-->\s*(\d\d):(\d\d):(\d\d),(\d\d\d)/);
        if (!match) return;
        const start = (+match[1]) * 3600 + (+match[2]) * 60 + (+match[3]) + (+match[4]) / 1000;
        const end = (+match[5]) * 3600 + (+match[6]) * 60 + (+match[7]) + (+match[8]) / 1000;
        const text2 = lines.slice(timeLineIndex + 1).join(" ").trim();
        if (text2) cues.push({ start, end, text: text2 });
    });
    return cues;
}

function toAssTime(seconds) {
    seconds = Math.max(0, seconds);
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const cs = Math.round((seconds - Math.floor(seconds)) * 100);
    const pad = (n) => String(n).padStart(2, "0");
    return `${h}:${pad(m)}:${pad(s)}.${pad(cs)}`;
}

// overrides: { strokeEnabled, strokeWidth, glowAmount }
function buildAssContent(cues, style, width, height, overrides) {
    overrides = overrides || {};
    const outline = overrides.strokeEnabled === false ? 0 : (overrides.strokeWidth != null ? overrides.strokeWidth : style.outline);
    const header = `[Script Info]
ScriptType: v4.00+
PlayResX: ${width}
PlayResY: ${height}
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,${style.fontName},${style.fontSize},${style.primaryColour},&H000000FF,${style.outlineColour},${style.backColour},${style.bold},0,0,0,100,100,0,0,${style.borderStyle},${outline},${style.shadow},${style.alignment},40,40,${style.marginV},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;
    // Pop animation: each line scales in from 0% to a 112% overshoot, then
    // settles to 100% - a classic bounce/pop-in, timed relative to that
    // line's own start (ASS \t transform times are cue-relative, in ms).
    // \blur applies a soft gaussian blur to the outline/shadow edges - the
    // standard libass technique for a "glow" look - driven by the slider.
    const glow = overrides.glowAmount || 0;
    const blurTag = glow > 0 ? `\\blur${glow}` : "";
    const pop = `{${blurTag}\\fscx0\\fscy0\\t(0,150,\\fscx112\\fscy112)\\t(150,260,\\fscx100\\fscy100)}`;
    const lines = cues.map((cue) => {
        const text = cue.text.replace(/\n/g, "\\N");
        return `Dialogue: 0,${toAssTime(cue.start)},${toAssTime(cue.end)},Default,,0,0,0,,${pop}${text}`;
    });
    return header + lines.join("\n") + "\n";
}

// ffmpeg's filtergraph syntax treats ':' and '\' specially, which breaks
// Windows paths (e.g. "C:\Users\...") unless escaped this way.
function escapeFfmpegFilterPath(p) {
    return p.replace(/\\/g, "/").replace(/:/g, "\\:");
}

function extractTrimmedAudio(mediaPath, inSeconds, durationSeconds, outPath) {
    return new Promise((resolve) => {
        const args = ["-y", "-ss", String(inSeconds), "-t", String(durationSeconds), "-i", mediaPath, "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", outPath];
        execFile(settings.ffmpegPath, args, { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) => {
            if (err) { resolve({ ok: false, error: "Could not extract audio: " + (stderr || err.message) }); return; }
            resolve({ ok: true, path: outPath });
        });
    });
}

function runWhisper(mediaPath, language, outDir) {
    return new Promise((resolve) => {
        // Support a multi-word command like "python -m whisper" - needed
        // whenever pip installs the whisper.exe launcher somewhere not on
        // PATH, which is a very common situation on Windows.
        const commandParts = settings.whisperPath.trim().split(/\s+/);
        const command = commandParts[0];
        const baseArgs = commandParts.slice(1);
        const args = baseArgs.concat([mediaPath, "--output_format", "srt", "--output_dir", outDir, "--verbose", "False"]);
        if (language && language !== "auto") args.push("--language", language);
        execFile(command, args, { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) => {
            if (err) {
                resolve({ ok: false, error: "Whisper failed: " + (stderr || err.message) + "\nIs Whisper installed and on PATH? (pip install -U openai-whisper)" });
                return;
            }
            const base = path.basename(mediaPath, path.extname(mediaPath));
            const srtPath = path.join(outDir, base + ".srt");
            if (!fs.existsSync(srtPath)) {
                resolve({ ok: false, error: "Whisper ran but produced no .srt file." });
                return;
            }
            resolve({ ok: true, srtPath: srtPath });
        });
    });
}

function renderSubtitleOverlay(assPath, width, height, duration, outPath) {
    return new Promise((resolve) => {
        const escapedAss = escapeFfmpegFilterPath(assPath);
        const args = [
            "-y",
            "-f", "lavfi", "-i", `color=c=black@0.0:s=${width}x${height}:d=${duration}`,
            "-vf", `subtitles='${escapedAss}'`,
            "-c:v", "qtrle",
            outPath
        ];
        execFile(settings.ffmpegPath, args, { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) => {
            if (err) { resolve({ ok: false, error: "ffmpeg render failed: " + (stderr || err.message) }); return; }
            resolve({ ok: true });
        });
    });
}

$("btnGenerateSubtitles").addEventListener("click", async () => {
    const language = $("subtitleLanguage").value;
    const style = SUBTITLE_STYLES[$("subtitleStyle").value];
    const overrides = {
        strokeEnabled: $("strokeEnabled").checked,
        strokeWidth: parseInt($("strokeWidth").value, 10),
        glowAmount: parseInt($("glowAmount").value, 10)
    };

    setStatus("Reading selected clip...");
    const clipInfo = await evalScript("$$eh_getSelectedVideoClip()");
    if (!clipInfo.ok) { setStatus("Error: " + clipInfo.error, true); return; }

    const frameInfo = await evalScript("$$eh_getFrameSize()");
    if (!frameInfo.ok) { setStatus("Error: " + frameInfo.error, true); return; }

    const tempDir = getCacheDir();
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    setStatus("Extracting audio for the selected clip...");
    const trimmedWavPath = path.join(tempDir, `trim_${Date.now()}.wav`);
    const trimResult = await extractTrimmedAudio(clipInfo.mediaPath, clipInfo.sourceIn || 0, clipInfo.duration, trimmedWavPath);
    if (!trimResult.ok) { setStatus(trimResult.error, true); return; }

    setStatus("Transcribing with Whisper (this can take a minute)...");
    const whisperResult = await runWhisper(trimmedWavPath, language, tempDir);
    if (!whisperResult.ok) { setStatus(whisperResult.error, true); return; }

    const srtText = fs.readFileSync(whisperResult.srtPath, "utf8");
    const cues = parseSrt(srtText);
    if (!cues.length) { setStatus("Whisper didn't detect any speech in this clip.", true); return; }

    setStatus(`Transcribed ${cues.length} line(s). Rendering styled subtitles...`);
    const assPath = path.join(tempDir, `subs_${Date.now()}.ass`);
    fs.writeFileSync(assPath, buildAssContent(cues, style, frameInfo.width, frameInfo.height, overrides), "utf8");

    const overlayPath = path.join(tempDir, `subs_${Date.now()}.mov`);
    const renderResult = await renderSubtitleOverlay(assPath, frameInfo.width, frameInfo.height, clipInfo.duration, overlayPath);
    if (!renderResult.ok) { setStatus(renderResult.error, true); return; }

    setStatus("Inserting subtitles onto the timeline...");
    const insertResult = await evalScript(`$$eh_insertOverlayAtTime(${JSON.stringify(overlayPath)}, ${clipInfo.start})`);
    if (!insertResult.ok) { setStatus("Error: " + insertResult.error, true); return; }

    setStatus(`Inserted styled subtitles (${cues.length} line(s)) on track V${insertResult.track + 1}.`);
});

// ---------------------------------------------------------------------------
// Quick Edit: personal Premiere presets + built-in one-click effects
// ---------------------------------------------------------------------------
function scanPresets(folder) {
    const results = [];
    function walk(dir) {
        let entries;
        try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
        catch (e) { return; }
        for (const entry of entries) {
            const full = path.join(dir, entry.name);
            if (entry.isDirectory()) { walk(full); continue; }
            if (path.extname(entry.name).toLowerCase() === ".prfpset") {
                results.push({ name: entry.name.replace(/\.prfpset$/i, ""), path: full });
            }
        }
    }
    if (folder) walk(folder);
    return results;
}

function renderPresetsList() {
    const container = $("presetsList");
    const presets = scanPresets(settings.presetsFolder);
    if (!presets.length) {
        container.innerHTML = `<div class="preset-empty">No presets found. Set your Premiere presets folder in Settings.</div>`;
        return;
    }
    container.innerHTML = "";
    presets.forEach((preset) => {
        const row = document.createElement("div");
        row.className = "preset-row";
        row.textContent = preset.name;
        row.title = preset.path;
        row.addEventListener("dblclick", () => applyPreset(preset));
        container.appendChild(row);
    });
}

async function applyPreset(preset) {
    setStatus(`Applying preset "${preset.name}"...`);
    const result = await evalScript(`$$eh_applyPresetToSelectedClip(${JSON.stringify(preset.path)})`);
    if (!result.ok) { setStatus("Error: " + result.error, true); return; }
    setStatus(`Applied preset "${preset.name}".`);
}

$("btnRefreshPresets").addEventListener("click", renderPresetsList);

const QUICK_EFFECTS = [
    { key: "zoomIn", name: "Zoom In", sliderMin: 0.1, sliderMax: 2, sliderStep: 0.1, sliderDefault: 0.4, labelFn: (v) => `${v.toFixed(1)}s ramp - lower = punchier` },
    { key: "zoomOut", name: "Zoom Out", sliderMin: 0.1, sliderMax: 2, sliderStep: 0.1, sliderDefault: 0.4, labelFn: (v) => `${v.toFixed(1)}s ramp - lower = punchier` },
    { key: "shake", name: "Camera Shake", sliderMin: 2, sliderMax: 40, sliderStep: 1, sliderDefault: 12, labelFn: (v) => `${v}px intensity` },
    { key: "impactPunch", name: "Impact Punch (zoom + shake)", sliderMin: 2, sliderMax: 40, sliderStep: 1, sliderDefault: 15, labelFn: (v) => `${v}px intensity` },
    { key: "whiteFlash", name: "White Flash", sliderMin: 0.05, sliderMax: 1, sliderStep: 0.05, sliderDefault: 0.2, labelFn: (v) => `${v.toFixed(2)}s flash` },
    { key: "blackFlash", name: "Black Flash", sliderMin: 0.05, sliderMax: 1, sliderStep: 0.05, sliderDefault: 0.2, labelFn: (v) => `${v.toFixed(2)}s flash` }
];

function renderQuickEffects() {
    const container = $("quickEffectsList");
    container.innerHTML = "";
    QUICK_EFFECTS.forEach((fx) => {
        const row = document.createElement("div");
        row.className = "quick-effect-row";
        row.innerHTML = `
            <div class="quick-effect-top">
                <span class="quick-effect-name">${fx.name}</span>
                <span class="quick-effect-value">${fx.labelFn(fx.sliderDefault)}</span>
            </div>
            <input type="range" min="${fx.sliderMin}" max="${fx.sliderMax}" step="${fx.sliderStep}" value="${fx.sliderDefault}" />
            <button class="quick-effect-apply">Apply to Selected Clip</button>
        `;
        const slider = row.querySelector("input[type=range]");
        const valueLabel = row.querySelector(".quick-effect-value");
        slider.addEventListener("input", () => {
            valueLabel.textContent = fx.labelFn(parseFloat(slider.value));
        });
        slider.addEventListener("click", (e) => e.stopPropagation());
        const apply = () => applyQuickEffect(fx.key, parseFloat(slider.value), fx.name);
        row.querySelector(".quick-effect-apply").addEventListener("click", apply);
        row.addEventListener("dblclick", apply);
        container.appendChild(row);
    });
}

async function applyQuickEffect(kind, value, label) {
    if (kind === "whiteFlash" || kind === "blackFlash") {
        await applyFlashEffect(kind, value, label);
        return;
    }
    setStatus(`Applying ${label}...`);
    const result = await evalScript(`$$eh_applyMotionEffect(${JSON.stringify(kind)}, ${value})`);
    if (!result.ok) { setStatus("Error: " + result.error, true); return; }
    setStatus(`Applied ${label}.`);
}

async function applyFlashEffect(kind, duration, label) {
    setStatus("Reading selected clip...");
    const clipInfo = await evalScript("$$eh_getSelectedVideoClip()");
    if (!clipInfo.ok) { setStatus("Error: " + clipInfo.error, true); return; }

    const frameInfo = await evalScript("$$eh_getFrameSize()");
    if (!frameInfo.ok) { setStatus("Error: " + frameInfo.error, true); return; }

    const tempDir = getCacheDir();
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    const color = kind === "whiteFlash" ? "white" : "black";
    const outPath = path.join(tempDir, `flash_${Date.now()}.mov`);
    const fadeHalf = (duration / 2).toFixed(3);

    setStatus(`Rendering ${label}...`);
    const args = [
        "-y",
        "-f", "lavfi", "-i", `color=c=${color}:s=${frameInfo.width}x${frameInfo.height}:d=${duration}`,
        "-vf", `format=yuva420p,fade=t=in:st=0:d=${fadeHalf}:alpha=1,fade=t=out:st=${fadeHalf}:d=${fadeHalf}:alpha=1`,
        "-c:v", "qtrle",
        outPath
    ];

    const renderOk = await new Promise((resolve) => {
        execFile(settings.ffmpegPath, args, { maxBuffer: 1024 * 1024 * 20 }, (err, stdout, stderr) => {
            if (err) { setStatus("ffmpeg render failed: " + (stderr || err.message), true); resolve(false); return; }
            resolve(true);
        });
    });
    if (!renderOk) return;

    setStatus("Inserting flash onto the timeline...");
    const insertResult = await evalScript(`$$eh_insertOverlayAtTime(${JSON.stringify(outPath)}, ${clipInfo.start})`);
    if (!insertResult.ok) { setStatus("Error: " + insertResult.error, true); return; }
    setStatus(`Inserted ${label} on track V${insertResult.track + 1}.`);
}

renderPresetsList();
renderQuickEffects();

// ---------------------------------------------------------------------------
// Meme / GIF finder
// ---------------------------------------------------------------------------
const GENRE_KEYWORDS = {
    minecraft: ["minecraft", "mc", "creeper", "steve", "enderman"],
    roblox: ["roblox", "noob", "oof"],
    trends: ["trend", "trending", "viral", "meme"],
    gaming: ["game", "gaming", "gamer", "gameplay", "esports"],
    documentary: ["documentary", "doc", "history", "science"],
    nature: ["nature", "wildlife", "animal", "outdoors", "landscape"],
    tech: ["tech", "technology", "gadget", "software", "ai"]
};

function httpsGetJson(url) {
    return new Promise((resolve, reject) => {
        https.get(url, (res) => {
            let data = "";
            res.on("data", (chunk) => (data += chunk));
            res.on("end", () => {
                try { resolve(JSON.parse(data)); }
                catch (e) { reject(e); }
            });
        }).on("error", reject);
    });
}

function downloadFile(url, destPath) {
    return new Promise((resolve, reject) => {
        const file = fs.createWriteStream(destPath);
        https.get(url, (res) => {
            res.pipe(file);
            file.on("finish", () => file.close(() => resolve(destPath)));
        }).on("error", (err) => {
            fs.unlink(destPath, () => {});
            reject(err);
        });
    });
}

async function searchGiphy(query, limit) {
    if (!settings.giphyKey) return [];
    const url = `https://api.giphy.com/v1/gifs/search?api_key=${encodeURIComponent(settings.giphyKey)}&q=${encodeURIComponent(query)}&limit=${limit}&rating=pg-13`;
    try {
        const data = await httpsGetJson(url);
        return (data.data || []).map((g) => ({
            source: "giphy",
            title: g.title,
            thumb: g.images.fixed_height_small.url,
            full: g.images.original.url,
            ext: ".gif"
        }));
    } catch (e) { return []; }
}

async function searchTenor(query, limit) {
    if (!settings.tenorKey) return [];
    const url = `https://tenor.googleapis.com/v2/search?key=${encodeURIComponent(settings.tenorKey)}&q=${encodeURIComponent(query)}&limit=${limit}&contentfilter=medium`;
    try {
        const data = await httpsGetJson(url);
        return (data.results || []).map((r) => ({
            source: "tenor",
            title: r.content_description,
            thumb: r.media_formats.tinygif ? r.media_formats.tinygif.url : r.media_formats.gif.url,
            full: r.media_formats.gif.url,
            ext: ".gif"
        }));
    } catch (e) { return []; }
}

function scanLocalFolder(folderPath, query, genre) {
    const exts = [".gif", ".png", ".jpg", ".jpeg", ".webp", ".mp4", ".mov"];
    const results = [];
    const q = (query || "").toLowerCase();
    const genreWords = genre && GENRE_KEYWORDS[genre] ? GENRE_KEYWORDS[genre] : null;

    function walk(dir) {
        let entries;
        try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
        catch (e) { return; }
        for (const entry of entries) {
            const full = path.join(dir, entry.name);
            if (entry.isDirectory()) { walk(full); continue; }
            const ext = path.extname(entry.name).toLowerCase();
            if (exts.indexOf(ext) === -1) continue;

            const base = entry.name.replace(ext, "");
            const tags = base.split(/[^a-zA-Z0-9]+/).filter(Boolean).map((s) => s.toLowerCase());
            tags.push(path.basename(dir).toLowerCase());

            const matchesQuery = !q || tags.some((t) => t.indexOf(q) !== -1);
            const matchesGenre = !genreWords || tags.some((t) => genreWords.indexOf(t) !== -1);

            if (matchesQuery && matchesGenre) {
                results.push({
                    source: "local",
                    title: entry.name,
                    thumb: "file://" + full,
                    full: full,
                    ext: ext
                });
            }
        }
    }

    if (folderPath) walk(folderPath);
    return results;
}

let lastResults = [];
let selectedResultIndex = -1;

$("btnSearch").addEventListener("click", async () => {
    const query = $("searchQuery").value.trim();
    const genre = $("genreFilter").value;
    const typeFilter = $("typeFilter").value;
    const effectiveQuery = genre && !query ? genre : query;

    setStatus("Searching...");
    $("resultsGrid").innerHTML = "";
    selectedResultIndex = -1;

    let results = [];

    if (genre === "recent") {
        const q = query.toLowerCase();
        results = loadRecentDownloads().filter((r) => !q || (r.title || "").toLowerCase().indexOf(q) !== -1);
    } else {
        if (typeFilter !== "local") {
            const [giphyResults, tenorResults] = await Promise.all([
                searchGiphy(effectiveQuery, 15),
                searchTenor(effectiveQuery, 15)
            ]);
            results.push(...giphyResults, ...tenorResults);
        }
        if (typeFilter !== "gif" || typeFilter === "local") {
            results.push(...scanLocalFolder(settings.localFolder, query, genre));
        }
    }

    lastResults = results;
    renderResults(results);

    if (!results.length) {
        setStatus("No results. Check your API keys / local folder in Settings, or try a different search.", true);
    } else {
        setStatus(`Found ${results.length} result(s).`);
    }
});

function renderResults(results) {
    const grid = $("resultsGrid");
    grid.innerHTML = "";
    results.forEach((r, i) => {
        const cell = document.createElement("div");
        cell.className = "result-cell";
        cell.innerHTML = `<img src="${r.thumb}" alt="${escapeHtml(r.title || "")}" /><div class="result-label">${escapeHtml(r.source)}</div>`;
        cell.addEventListener("click", () => {
            document.querySelectorAll(".result-cell").forEach((c) => c.classList.remove("selected"));
            cell.classList.add("selected");
            selectedResultIndex = i;
        });
        grid.appendChild(cell);
    });
}

function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

$("btnInsert").addEventListener("click", async () => {
    if (selectedResultIndex < 0) { setStatus("Select a result first.", true); return; }
    const result = lastResults[selectedResultIndex];
    const mode = $("insertMode").value;

    setStatus("Preparing media...");
    let localPath = result.full;
    const alreadyLocal = result.source === "local" || result.source === "recent";

    if (!alreadyLocal) {
        try {
            const cacheDir = getCacheDir();
            if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
            const fileName = `meme_${Date.now()}${result.ext}`;
            localPath = path.join(cacheDir, fileName);
            setStatus("Downloading media...");
            await downloadFile(result.full, localPath);
            addRecentDownload({ source: "recent", title: result.title, thumb: localPath, full: localPath, ext: result.ext });
        } catch (e) {
            setStatus("Download failed: " + e.message, true);
            return;
        }
    }

    setStatus("Inserting into the timeline...");
    const insertResult = await evalScript(`$$eh_insertMediaAtPlayhead(${JSON.stringify(localPath)}, "${mode}")`);
    if (!insertResult.ok) { setStatus("Error: " + insertResult.error, true); return; }
    setStatus(`Inserted on track V${insertResult.track + 1} at ${insertResult.time.toFixed(2)}s.`);
});

// ---------------------------------------------------------------------------
// Settings tab
// ---------------------------------------------------------------------------
function populateSettingsForm() {
    $("giphyKey").value = settings.giphyKey;
    $("tenorKey").value = settings.tenorKey;
    $("localFolder").value = settings.localFolder;
    $("presetsFolder").value = settings.presetsFolder;
    $("ffmpegPath").value = settings.ffmpegPath;
    $("whisperPath").value = settings.whisperPath;
    $("targetLufs").value = settings.targetLufs;
    $("minGap").value = settings.minGapSeconds;
}

$("btnSaveSettings").addEventListener("click", () => {
    settings.giphyKey = $("giphyKey").value.trim();
    settings.tenorKey = $("tenorKey").value.trim();
    settings.localFolder = $("localFolder").value.trim();
    settings.presetsFolder = $("presetsFolder").value.trim();
    settings.ffmpegPath = $("ffmpegPath").value.trim() || "ffmpeg";
    settings.whisperPath = $("whisperPath").value.trim() || "whisper";
    saveSettings(settings);
    setStatus("Settings saved.");
    renderPresetsList();
});

$("btnBrowseFolder").addEventListener("click", () => {
    // No native folder picker without extra Node deps - accept a pasted path instead.
    setStatus("Paste the full path to your meme/GIF folder into the field, then click Save.");
});

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------
async function init() {
    populateSettingsForm();
    const status = await evalScript("$$eh_getStatus()");
    const versionTag = status.hostVersion ? ` [host ${status.hostVersion}]` : " [host version unknown - very old host/index.jsx]";
    if (status.ok && status.hasSequence) {
        setStatus(`Connected to sequence "${status.sequenceName}".${versionTag}`);
    } else if (status.ok) {
        setStatus(`Open a sequence in Premiere Pro to get started.${versionTag}`);
    } else {
        setStatus("Error talking to Premiere: " + status.error, true);
    }
}

init();
